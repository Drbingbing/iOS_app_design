//
//  TableViewController.swift
//  iCloudKit
//
//  Created by Dr. BingBing on 18/01/2018.
//  Copyright © 2018 Dr.BingBing. All rights reserved.
//

import UIKit
import CloudKit

class TableViewController: UITableViewController {
    
    @IBOutlet var spinner: UIActivityIndicatorView!
    
    var restaurants: [CKRecord] = []
    
    // 建立快取物件，NSCache為泛型(generic)。
    // 初始化時必須要在<>內提供鍵值配對的型態，這裡 CKRecordID為鍵，NSURL為值的型態
    var imageCache = NSCache<CKRecordID, NSURL>()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // 動態指示器
        spinner.hidesWhenStopped = true
        spinner.center = view.center
        tableView.addSubview(spinner)
        spinner.startAnimating()
        // 下拉更新
        refreshControl = UIRefreshControl()
        refreshControl?.backgroundColor = UIColor.white
        refreshControl?.tintColor = UIColor.gray
        refreshControl?.addTarget(self, action: #selector(fetchRecordsFromCloud), for: UIControlEvents.valueChanged)
        
        fetchRecordsFromCloud()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    @objc func fetchRecordsFromCloud() {
        
        restaurants.removeAll()
        tableView.reloadData()
        
        let cloudContainer = CKContainer.default()
        let publicDatabase = cloudContainer.publicCloudDatabase
        let predicate = NSPredicate(value: true)
        let query = CKQuery(recordType: "Restaurant", predicate: predicate)
        
        // 以query建立查詢操作
        let queryOperation = CKQueryOperation(query: query)
        // 選擇要的紀錄欄位
        queryOperation.desiredKeys = ["name", "type", "phone"]
        // 執行優先順序
        queryOperation.queuePriority = .veryHigh
        // 設定任何時間回傳最大的紀錄數
        queryOperation.resultsLimit = 50
        // 在recordFetchedBlock內的程式碼會在每一筆資料回傳時執行，這裡把資料加入restaurant陣列
        queryOperation.recordFetchedBlock = { (record) -> Void in
            self.restaurants.append(record)
        }
        // 在queryCompletionBlock內是所有資料取得之後執行，請求表格視圖重新載入並顯示餐廳紀錄
        queryOperation.queryCompletionBlock = {(cursor, error) -> Void in
            if let error = error {
                print("Failed to get data from iCloud")
                return
            }
            
            print("Successfull retrieve the data from iCloud")
            OperationQueue.main.addOperation {
                self.spinner.stopAnimating()
                self.tableView.reloadData()
                
                if let refreshControl = self.refreshControl {
                    if refreshControl.isRefreshing {
                        refreshControl.endRefreshing()
                    }
                }
            }
        }
        
        // 執行查詢
        publicDatabase.add(queryOperation)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return restaurants.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TableViewCell

        // Configure the cell...
        let restaurant = restaurants[indexPath.row]
        cell.nameLabel?.text = restaurant.object(forKey: "name") as? String
        cell.typeLabel?.text = restaurant.object(forKey: "type") as? String
        cell.phoneLabel?.text = restaurant.object(forKey: "phone") as? String
        cell.nameLabel.font = UIFont(name: "MarkerFelt-Wide", size: 18.0)
        cell.typeLabel.font = UIFont(name: "MarkerFelt-Thin", size: 15.0)
        cell.phoneLabel.font = UIFont(name: "MarkerFelt-Thin", size: 15.0)
        cell.ImageView?.image = UIImage(named: "photoalbum")
        
        if let imageFileURL = imageCache.object(forKey: restaurant.recordID) {
            print("Get image from cache")
            if let imageData = try?Data.init(contentsOf: imageFileURL as URL){
                cell.ImageView?.image = UIImage(data: imageData)
            }
        }else {
            // 在背景從雲端取得資料
            let publicDatabase = CKContainer.default().publicCloudDatabase
            // 使用CKFetchRecordsOperation取得特定紀錄，再以這個特定紀錄的ID建立CKFetchRecordsOperation物件
            // 記錄取得後指定一個程式碼區塊perRecordCompletionBlock來執行
            let fetchRecordsImageOperation = CKFetchRecordsOperation(recordIDs: [restaurant.recordID])
            fetchRecordsImageOperation.desiredKeys = ["image"]
            fetchRecordsImageOperation.queuePriority = .veryHigh
            
            fetchRecordsImageOperation.perRecordCompletionBlock = { (record, recordID, error) -> Void in
                if let error = error {
                    print("Failed to get restaurant")
                    return
                }
                if let restaurantRecord = record{
                    OperationQueue.main.addOperation {
                        if let image = restaurantRecord.object(forKey: "image") {
                            let imageAsset = image as! CKAsset
                        
                            if let imageData = try?Data.init(contentsOf: imageAsset.fileURL) {
                                cell.ImageView?.image = UIImage(data: imageData)
                            }
                            // 加入圖片至快取中
                            self.imageCache.setObject(imageAsset.fileURL as NSURL, forKey: restaurant.recordID)
                        }
                    }
                }
            }
            publicDatabase.add(fetchRecordsImageOperation)
        }
        return cell
    }
    
    @IBAction func unwindToHomeScreen(seague: UIStoryboardSegue) {
    }
}
