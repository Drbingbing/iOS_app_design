//
//  WalkthroughContentViewController.swift
//  walkthrough
//
//  Created by Dr. BingBing on 2018/1/11.
//  Copyright © 2018年 Dr. BingBing. All rights reserved.
//

import UIKit

class WalkthroughContentViewController: UIViewController {

    @IBOutlet weak var contentImageView: UIImageView!
    @IBOutlet weak var headingLabel: UILabel!
    @IBOutlet weak var contentLabel: UILabel!
    @IBOutlet weak var pagecontrol: UIPageControl!
    @IBOutlet weak var forwardButton: UIButton!
    
    // 儲存索引值的變數
    var index = 0
    var heading = ""
    var content = ""
    var imageFile = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        customText()
        // 初始化圖片視圖
        headingLabel.text = heading
        contentLabel.text = content
        contentImageView.image = UIImage(named: imageFile)
        pagecontrol.currentPage = index
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func customText () {
        headingLabel.font = UIFont(name: "MarkerFelt-Thin", size: 25)
        contentLabel.font = UIFont(name: "Noteworthy-Bold", size: 17)
        
        switch index {
        case 0...1:
            forwardButton.setTitle("NEXT", for: .normal)
        case 2:
            forwardButton.setTitle("DONE", for: .normal)
        default:
            break
        }
        
    }

    
    // UserDefaults 是可以儲存使用者偏好，要儲存設定到預設系統，要以一個特定鍵來設特定值
    @IBAction func nextButtonTapped(_ sender: Any) {
        
        switch index {
        case 0...1:
            let pageViewController = parent as! WalkPageViewController
            pageViewController.forward(index: index)
        case 2:
            UserDefaults.standard.set(true, forKey: "hasViewedWalkthrough")
            dismiss(animated: true, completion: nil)
            
        default:
            break
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
